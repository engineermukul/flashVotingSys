package net.codejava.email;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import rgen.RandomPasswordGenerator;

import dbConnection.MyConnection;

/**
 * A servlet that takes message details from user and send it as a new e-mail
 * through an SMTP server.
 * 
 * @author www.codejava.net
 * 
 */
@WebServlet("/EmailSendingServlet")
public class EmailSendingServlet extends HttpServlet {
	private String host;
	private String port;
	private String user;
	private String pass;

	public void init() {
		// reads SMTP server setting from web.xml file
		ServletContext context = getServletContext();
		host = context.getInitParameter("host");
		port = context.getInitParameter("port");
		user = context.getInitParameter("user");
		pass = context.getInitParameter("pass");
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// reads form fields
		MyConnection mc=new MyConnection();
		Connection con=mc.getConnected();
		ResultSet rs=null;
		Statement st=null;
		HttpSession session=null;
		String recipient =null;
		try {
			st=con.createStatement();
			session=request.getSession();
			rs=st.executeQuery("select email from voter where voter_id='"+session.getAttribute("vid").toString()+"'");
		if(rs.next()){
				recipient = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
		String uname=new String(RandomPasswordGenerator.generatePswd(10, 10, 3,	4 ,0));
		String pwd=new  String (RandomPasswordGenerator.generatePswd(10, 10, 3, 4, 2));
		String subject = "Confidential: Flash Voting Temporary UserName and password";
		String content ="Hey "+session.getAttribute("name").toString()+" ! Your temporary UserName and password for Flash Voting is\n Username:"+uname+"\nPassword:"+pwd+"";
		String resultMessage = "";

		try {
			EmailUtility.sendEmail(host, port, user, pass, recipient, subject,
					content);
			resultMessage = "The e-mail was sent successfully";
			Statement st1=con.createStatement();
			int res=st1.executeUpdate("update voter set user_name='"+uname+"',password='"+pwd+"'where voter_id='"+session.getAttribute("vid").toString()+"'");
			if(res==1)System.out.println("Success set U&P");
			st1.close();
			
			getServletContext().getRequestDispatcher("/voterlogins2.jsp").forward(
					request, response);
		} catch (Exception ex) {
			ex.printStackTrace();
			//resultMessage = "There were an error: " + ex.getMessage();
			getServletContext().getRequestDispatcher("/notconnected.jsp").forward(
					request, response);
			
		} finally {
			//request.setAttribute("Message", resultMessage);
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}